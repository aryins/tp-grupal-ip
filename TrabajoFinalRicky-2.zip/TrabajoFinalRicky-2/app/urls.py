from django.contrib import admin  # type: ignore
from django.urls import path  # type: ignore
from . import views

urlpatterns = [
    # Rutas originales
    path('', views.index_page, name='index-page'),  # Página principal
    path('login/', views.index_page, name='login'),
    path('home/', views.home, name='home'),
    path('buscar/', views.search, name='buscar'),

    # Rutas de favoritos
    path('favourites/', views.getAllFavouritesByUser, name='favoritos'),
    path('favourites/add/', views.saveFavourite, name='agregar-favorito'),
    path('favourites/delete/', views.deleteFavourite, name='borrar-favorito'),

    # Salir
    path('exit/', views.exit, name='exit'),

    # Nueva ruta específica
    path('index/', views.index, name='index_page'),  # Otra vista específica
]
